//
//  UserObject.swift
//  FireInsta
//
//  Created by Sium on 8/20/17.
//  Copyright © 2017 Refat. All rights reserved.
//

import UIKit

class UserObject: NSObject {
    
    var userID: String!
    var fullName: String!
    var imagePath: String!
}
